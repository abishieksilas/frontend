export interface ICustomer {
  customerId: number,
  name: string,
  phone: string,
  gender: string,
  emailId: string,
  address: string,
  password: string
}