import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
    constructor() { }
       public  eid:any;
      public fname:any;
      public lname:any;
      public age:any;
      public gender:any;
      public email:any;
      public username:any;
      public passward:any;      

}
