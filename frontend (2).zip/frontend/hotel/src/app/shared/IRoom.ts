export interface IRoom {
    roomNo: number,
    roomType: string,
    capacity: number,
    status: string,
    price: number
}